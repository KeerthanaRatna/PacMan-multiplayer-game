

/**
 *
 * @author r_kee
 */
public class newNcolide {
       Players[] plyr = new Players[4];
    
    public newNcolide(Players [] plyr) {
        this.plyr=plyr;
        
    }
    void updateMarksCollison(){
    
        for(int i=0;i<4;i++){           
            for(int j=0;j<4;j++){ 
               
               if(plyr[i].string.equals(plyr[j].string)){
                   if(i!=j && (i==0 || j==0)){    
                            plyr[0].x=0;
                            plyr[0].y=0;
                            plyr[0].score= plyr[0].score-3;
                   }
                     if(i!=j && (i==1 || j==1)){    
                            plyr[1].x=44;
                            plyr[1].y=0;
                            plyr[1].score= plyr[1].score-3;
                   }
                       if(i!=j && (i==2 || j==2)){    
                            plyr[2].x=0;
                            plyr[2].y=44;
                            plyr[2].score= plyr[2].score-3;
                   }
                         if(i!=j && (i==3 || j==3)){    
                            plyr[3].x=44;
                            plyr[3].y=44;
                            plyr[3].score= plyr[3].score-3;
                   }
                       
                }
        }
        }
    }
}
