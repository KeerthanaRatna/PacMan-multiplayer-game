/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Tharindu
 */
@WebServlet(urlPatterns = {"/game", "/UpdateGame"})
public class UpdateGame extends HttpServlet {

    static int playerCount = 0;
    public String out1, dots, name1;
    Players[] players = new Players[4];
    grid g=new grid();
    String v=g.chaStringG();
    public HashMap<String,String> ha=g.hmap;
    newNcolide col;
    
    @Override
    public void init() throws ServletException {
        players[0] = new Players(0,0, 0, "P1");
    players[1] = new Players(0,44, 0, "P2");
    players[2] = new Players(44,0, 0, "P3");
    players[3] = new Players(44,44, 0, "P4");
        
        col=new newNcolide(players);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/event-stream;charset=UTF-8");

        try (final PrintWriter out = response.getWriter()) {
            Object attribute = request.getSession().getAttribute("player");
            if (attribute == null) {
                if (playerCount <= 3) {
                    request.getSession().setAttribute("player", players[playerCount++]);
                }
            }

            while (!Thread.interrupted()) {
                synchronized (this) {
                     
                    out1 = v+ "\"PLAYERS\": [" + players[0].chaString() + ", " + players[1].chaString() + ", " + players[2].chaString() + ", " + players[3].chaString() + "] }";
                    //System.out.println(out1);
                    out.println("data: " + out1);
                    out.println();
                    out.flush();
                 //   Logger.getGlobal().log(Level.INFO, out1);
                    wait();
                }

            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
            synchronized (this) {
                String k = request.getParameter("keypress");

                Players player = (Players) request.getSession().getAttribute("player");
                
                player.hmP=ha;
               int k1 = Integer.valueOf(k);
               if (k1 == 37) {
                    //player.update(-1, 0);
                     player.update();
                    player.x--;
                    v=g.updateFood(player.string);
                }
                if (k1 == 38) {
                    //player.update(0, -1);
                    player.update();
                    player.y--;
                    v=g.updateFood(player.string);
                }
                if (k1 == 39) {
                    //player.update(1, 0);
                    player.update();
                    player.x++;
                    v=g.updateFood(player.string);
                }
                if (k1 == 40) {
                    //player.update(0, 1);
                    player.update();
                    player.y++;
                    v=g.updateFood(player.string);
                }
//                if (k1 == 37) {
//                    int updated = player.getX() - 1 ;
//             player.setX(updated);
//                    player.update();
//                    
//                   v= g.updateFood(player.string);
//                    //v=g.chaStringG();
//                }
//                if (k1 == 38) {
//                     int updated = player.getY() - 1 ;
//             player.setY(updated);
//                    player.update();
//                    v=g.updateFood(player.string);
//                    //v=g.chaStringG();
//                }
//                if (k1 == 39) {
//                     int updated = player.getX() + 1 ;
//             player.setX(updated);
//                    player.update();
//                    v=g.updateFood(player.string);
//                    //v=g.chaStringG();
//                }
//                if (k1 == 40) {
//                     int updated = player.getY() +1 ;
//             player.setY(updated);
//                    player.update();
//                   v= g.updateFood(player.string);
//                    //v=g.chaStringG();
//                }
                ha=g.hmap;
                col.updateMarksCollison();
                notifyAll();
            }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
