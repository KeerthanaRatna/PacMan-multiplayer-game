

import java.util.HashMap;
import java.util.Random;

/**
 * Created by r_kee on 13-5-2017.
 */

    public class grid {

    int x;
    int y;
    String color;
    int[] position;
    public HashMap<String, String> hmap = new HashMap<>();
    public HashMap<String, String> hmapS = new HashMap<>();
    
    
    Random random = new Random();
    String concat;

    //    GameGrid(int x, int y, String color) {
//        this.x = x;
//        this.y = y;
//        this.color = color;
//        concat = x+","+y;
//    }
    public int Positions(int min, int max) {
        int randomInt = min + random.nextInt(max - min + 1);
        return randomInt;

    }

    public int noOFColors(String color) {
        if (color.equals("R")) {
            return Positions(2, 10);
        }
        if (color.equals("G")) {
            return Positions(2, 10);
        }
        if (color.equals("B")) {
            return Positions(2, 10);
        }
        return 0;

    }

    String string;

    public void foodPositions(String color) {

        if (color.equals("B")) { 

            for (int i = 0; i < noOFColors("B"); i++) {
                int positionX = Positions(0, 40);
                int positionY = Positions(0, 40);

                string = positionX + "," + positionY;
                String val="[\""+color+"\", "+positionX+", "+positionY+"]";
                hmap.put(string, "B");
                hmapS.put(string,val);

            }
        }
        if (color.equals("R")) {
            for (int i = 0; i < noOFColors("R"); i++) {
                int positionX = Positions(0, 40);
                int positionY = Positions(0, 40);
                string = positionX + "," + positionY;
                String val="[\""+color+"\", "+positionX+", "+positionY+"]";
                hmap.put(string, "R");
                hmapS.put(string,val);
            }
        }
        if (color.equals("G")) {
            for (int i = 0; i < noOFColors("G"); i++) {
                int positionX = Positions(0, 40);
                int positionY = Positions(0, 40);
                string = positionX + "," + positionY;
                String val="[\""+color+"\", "+positionX+", "+positionY+"]";
                hmap.put(string, "G");
                hmapS.put(string,val);
            }
        }
    }
    boolean initial=true;
        String updateFood(String cordString) {
            String dots = null;

            if (hmap.containsKey(cordString)) {
                hmap.remove(cordString);
                hmapS.remove(cordString);
                //hmap.remove(cords);
            }
            
            if(hmap.isEmpty()){
                if(initial==true){
                foodPositions("B");
                foodPositions("G");
                foodPositions("R");
                initial=false;
                }
                else{
                    dots="{ \"DOTS\":"+null;
                    
                    
                }
            }
//            for (String name : hmap.keySet()) {
//                // dots[0]="[" + hmap.get(name)+ ","+name+"]";
//                
//                String num[] = name.split(",");
//                int num1 = Integer.parseInt(num[0]);
//                int num2 = Integer.parseInt(num[1]);
////
//
//                if (dots == null) {
//                    dots = "{ \"DOTS\": [[\"" + hmap.get(name) + "\"," + num1 + "," + num2 + "]";
//                }
//                dots = dots + ",[\"" + hmap.get(name) + "\"," + num1 + "," + num2 + "]";
//            }
//            dots = dots + "],";
//            return dots;
            else{
        dots="{ \"DOTS\": [";
        boolean state= true;
        for (String nam: this.hmapS.keySet()){
            if(state==true){
                dots=dots+hmapS.get(nam);
                state=false;
            }
            dots=dots+","+hmapS.get(nam);
        }
        dots=dots+" ],";
            }
        return dots;

        }

    //
        public String chaStringG() {
            foodPositions("B");
            foodPositions("G");
            foodPositions("R");
           // String dots = null;


          //  for (String name : hmap.keySet()) {
                // dots[0]="[" + hmap.get(name)+ ","+name+"]";
//                String num[] = name.split(",");
//                int num1 = Integer.parseInt(num[0]);
//                int num2 = Integer.parseInt(num[1]);
//
//
//                if (dots == null) {
//                    dots = "{ \"DOTS\": [[\"" + hmap.get(name) + "\"," + num1 + "," + num2 + "]";
//                }
//                dots = dots + ",[\"" + hmap.get(name) + "\"," + num1 + "," + num2 + "]";
//            }
//            dots = dots + "],";
//
//            return dots;


String dot=null;
        for (String nam: this.hmapS.keySet()){
            if(dot==null){
                dot="{ \"DOTS\": ["+hmapS.get(nam);
            }
            dot=dot+","+hmapS.get(nam);
        }
        dot=dot+" ],";
        return dot;
        }



}
