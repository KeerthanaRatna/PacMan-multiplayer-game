

import java.util.HashMap;
import java.util.Random;

/**
 *
 * @author peshali
 */
public class Players {

    String player;
    int x;
    int y;
    int score;
    String string;
    public HashMap<String,String> hmP;
    Random ran = new Random();

    

    Players(int x, int y, int score, String player) {

        this.x = x;
        this.y = y;
        this.player = player;
        this.score = score;
        string = x+","+y;
    }


    void update(){

        if (x==-1){
            x=44;
        }
        if (x==45){
            x=0;
        }
        
        if (y==-1){
            y=44;
        }
        if (y==45){
            y=0;
        }
        string = x+","+y;
        if(hmP.containsKey(string)){
            if(hmP.get(string).equals("B")){
                score=score+1;
            }
             if(hmP.get(string).equals("R")){
                score=score+2;
            }
             if(hmP.get(string).equals("G")){
                score=score+3;
            }
        }
    }
    String chaString(){
        String pla="[\""+player+"\", "+score+", "+x+", "+y+"]";
        return pla;
    }
}
